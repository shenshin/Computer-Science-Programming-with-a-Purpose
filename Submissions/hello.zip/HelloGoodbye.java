/* *****************************************************************************
 *  Name:              Aleksandr Shenshin
 *  Coursera User ID:  ******
 *  Last modified:     3/5/2020
 **************************************************************************** */

public class HelloGoodbye {

    public static void main(String[] args) {

        String first = args[0];
        String second = args[1];

        System.out.println("Hello " + first + " and " + second + ".");
        System.out.println("Goodbye " + second + " and " + first + ".");
    }

}
